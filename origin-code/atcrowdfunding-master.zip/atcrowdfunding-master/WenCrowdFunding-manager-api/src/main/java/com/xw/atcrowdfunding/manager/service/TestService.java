package com.xw.atcrowdfunding.manager.service;

public interface TestService {
	
	public void insert();

}
