package com.xw.atcrowdfunding.manager.dao;

import java.util.Map;

public interface TestDao {
	
	public void insert(Map map);

}
