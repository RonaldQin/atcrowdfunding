package com.xw.atcrowdfunding.util;

public class Const {
    public static final String LOGIN_USER = "user";
    public static final String PASSWORD = "123";
    public static final String MY_URIS = "myURIs";
    public static final String ALL_PERMISSION_URI = "allPermissionUris";
    public static final String LOGIN_MEMBER = "loginMember";
}
